#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

namespace NinjaTrader.NinjaScript.Indicators
{
	public class CombinedTrendIndicator : Indicator
	{
		// TrendLines S/R Classes
		private class PivotPoint
		{
			public int Index { get; set; }
			public double Price { get; set; }
			
			public PivotPoint(int index, double price)
			{
				Index = index;
				Price = price;
			}
		}
		
		private class TrendLineData
		{
			public PivotPoint Start { get; set; }
			public PivotPoint End { get; set; }
			public bool IsViolated { get; set; }
			public string Tag { get; set; }
			
			public TrendLineData(PivotPoint start, PivotPoint end, string tag)
			{
				Start = start;
				End = end;
				IsViolated = false;
				Tag = tag;
			}
			
			public double GetPriceAtBar(int barIndex)
			{
				if (Start.Index == End.Index) return Start.Price;
				
				double slope = (End.Price - Start.Price) / (End.Index - Start.Index);
				return Start.Price + slope * (barIndex - Start.Index);
			}
		}
		
		private class SRLevel
		{
			public int Index { get; set; }
			public double Price { get; set; }
			public string Tag { get; set; }
			
			public SRLevel(int index, double price, string tag)
			{
				Index = index;
				Price = price;
				Tag = tag;
			}
		}
		
		// TrendLines S/R variables
		private List<PivotPoint> highPivots = new List<PivotPoint>();
		private List<PivotPoint> lowPivots = new List<PivotPoint>();
		private List<TrendLineData> uptrends = new List<TrendLineData>();
		private List<TrendLineData> downtrends = new List<TrendLineData>();
		private List<SRLevel> supports = new List<SRLevel>();
		private List<SRLevel> resistances = new List<SRLevel>();
		private int lineCounter = 0;
		
		// PPST variables
		private double ppstCenter = double.NaN;
		private double ppstTUp = double.NaN;
		private double ppstTDown = double.NaN;
		private int ppstTrend = 0;
		
		private Series<double> ppstPivotHighSeries;
		private Series<double> ppstPivotLowSeries;
		private Series<double> ppstCenterSeries;
		private Series<double> ppstTUpSeries;
		private Series<double> ppstTDownSeries;
		private Series<int> ppstTrendSeries;
		private ATR atr;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description = @"Combined TrendLines S/R and Pivot Point SuperTrend";
				Name = "Combined Trend Indicator";
				Calculate = Calculate.OnBarClose;
				IsOverlay = true;
				DisplayInDataBox = true;
				DrawOnPricePanel = true;
				DrawHorizontalGridLines = true;
				DrawVerticalGridLines = true;
				PaintPriceMarkers = true;
				ScaleJustification = NinjaTrader.Gui.Chart.ScaleJustification.Right;
				IsSuspendedWhileInactive = true;
				
				// TrendLines S/R Parameters
				TSR_PivotLength = 5;
				TSR_MarkPivots = true;
				TSR_TrendLinesEnabled = true;
				TSR_TL_PointsToCheck = 3;
				TSR_SR_Enabled = true;
				TSR_SR_PointsToCheck = 3;
				TSR_HighColor = Brushes.Red;
				TSR_LowColor = Brushes.Lime;
				
				// PPST Parameters
				PPST_PivotPeriod = 2;
				PPST_ATRFactor = 3.0;
				PPST_ATRPeriod = 10;
				PPST_ShowBuySellLabels = true;
				PPST_ShowCenterLine = false;
				
				// Plots
				AddPlot(Brushes.Lime, "PPST_SuperTrend");
				AddPlot(Brushes.Blue, "PPST_CenterLine");
			}
			else if (State == State.Configure)
			{
				atr = ATR(PPST_ATRPeriod);
			}
			else if (State == State.DataLoaded)
			{
				ppstPivotHighSeries = new Series<double>(this);
				ppstPivotLowSeries = new Series<double>(this);
				ppstCenterSeries = new Series<double>(this);
				ppstTUpSeries = new Series<double>(this);
				ppstTDownSeries = new Series<double>(this);
				ppstTrendSeries = new Series<int>(this);
			}
		}

		protected override void OnBarUpdate()
		{
			if (CurrentBar < Math.Max(TSR_PivotLength * 2, PPST_PivotPeriod * 2 + PPST_ATRPeriod))
			{
				Values[0][0] = double.NaN;
				Values[1][0] = double.NaN;
				return;
			}
			
			// Process TrendLines S/R
			ProcessTrendLinesSR();
			
			// Process PPST
			ProcessPPST();
		}
		
		private void ProcessTrendLinesSR()
		{
			// Detect swing pivots
			if (CurrentBar >= TSR_PivotLength * 2)
			{
				// Check for high pivot
				bool isHighPivot = true;
				double centerHigh = High[TSR_PivotLength];
				
				for (int i = 1; i <= TSR_PivotLength; i++)
				{
					if (High[TSR_PivotLength - i] >= centerHigh || High[TSR_PivotLength + i] >= centerHigh)
					{
						isHighPivot = false;
						break;
					}
				}
				
				if (isHighPivot)
				{
					PivotPoint newHigh = new PivotPoint(CurrentBar - TSR_PivotLength, centerHigh);
					highPivots.Add(newHigh);
					
					if (TSR_MarkPivots)
					{
						Draw.TriangleDown(this, "HighPivot" + CurrentBar, true, TSR_PivotLength, centerHigh + TickSize, TSR_HighColor);
					}
					
					// Paint resistance bar
					BarBrush = Brushes.Red;
					CandleOutlineBrush = Brushes.DarkRed;
					
					// Process support/resistance
					if (TSR_SR_Enabled)
					{
						ProcessResistance(newHigh);
					}
					
					// Process downtrends
					if (TSR_TrendLinesEnabled)
					{
						ProcessDowntrends(newHigh);
					}
				}
				
				// Check for low pivot
				bool isLowPivot = true;
				double centerLow = Low[TSR_PivotLength];
				
				for (int i = 1; i <= TSR_PivotLength; i++)
				{
					if (Low[TSR_PivotLength - i] <= centerLow || Low[TSR_PivotLength + i] <= centerLow)
					{
						isLowPivot = false;
						break;
					}
				}
				
				if (isLowPivot)
				{
					PivotPoint newLow = new PivotPoint(CurrentBar - TSR_PivotLength, centerLow);
					lowPivots.Add(newLow);
					
					if (TSR_MarkPivots)
					{
						Draw.TriangleUp(this, "LowPivot" + CurrentBar, true, TSR_PivotLength, centerLow - TickSize, TSR_LowColor);
					}
					
					// Paint support bar
					BarBrush = Brushes.Lime;
					CandleOutlineBrush = Brushes.Green;
					
					// Process support/resistance
					if (TSR_SR_Enabled)
					{
						ProcessSupport(newLow);
					}
					
					// Process uptrends
					if (TSR_TrendLinesEnabled)
					{
						ProcessUptrends(newLow);
					}
				}
			}
			
			// Draw active trend lines and S/R levels
			DrawTrendLines();
			DrawSupportResistance();
		}
		
		private void ProcessPPST()
		{
			// Get PPST Pivot High/Low
			double ph = GetPPSTPivotHigh(PPST_PivotPeriod);
			double pl = GetPPSTPivotLow(PPST_PivotPeriod);
			
			ppstPivotHighSeries[0] = ph;
			ppstPivotLowSeries[0] = pl;
			
			// Calculate the Center line using pivot points
			double lastpp = !double.IsNaN(ph) && ph > 0 ? ph : !double.IsNaN(pl) && pl > 0 ? pl : double.NaN;
			
			if (!double.IsNaN(lastpp))
			{
				if (double.IsNaN(ppstCenter))
				{
					ppstCenter = lastpp;
				}
				else
				{
					ppstCenter = (ppstCenter * 2 + lastpp) / 3;
				}
			}
			
			ppstCenterSeries[0] = ppstCenter;

			// Upper/lower bands calculation
			double up = ppstCenter - (PPST_ATRFactor * atr[0]);
			double dn = ppstCenter + (PPST_ATRFactor * atr[0]);

			// Get the trend
			if (CurrentBar == 0)
			{
				ppstTUp = up;
				ppstTDown = dn;
				ppstTrend = 1;
			}
			else
			{
				ppstTUp = Close[1] > ppstTUpSeries[1] ? Math.Max(up, ppstTUpSeries[1]) : up;
				ppstTDown = Close[1] < ppstTDownSeries[1] ? Math.Min(dn, ppstTDownSeries[1]) : dn;
				
				if (Close[0] > ppstTDownSeries[1])
					ppstTrend = 1;
				else if (Close[0] < ppstTUpSeries[1])
					ppstTrend = -1;
				else
					ppstTrend = ppstTrendSeries[1] != 0 ? ppstTrendSeries[1] : 1;
			}
			
			ppstTUpSeries[0] = ppstTUp;
			ppstTDownSeries[0] = ppstTDown;
			ppstTrendSeries[0] = ppstTrend;

			double trailingsl = ppstTrend == 1 ? ppstTUp : ppstTDown;

			// Plot the trend with color
			Values[0][0] = trailingsl;
			
			if (ppstTrend == 1 && CurrentBar > 0 && ppstTrendSeries[1] == 1)
				PlotBrushes[0][0] = Brushes.Lime;
			else if (ppstTrend == -1 && CurrentBar > 0 && ppstTrendSeries[1] == -1)
				PlotBrushes[0][0] = Brushes.Red;
			else
				PlotBrushes[0][0] = Brushes.Transparent;

			// Plot center line
			if (PPST_ShowCenterLine)
			{
				Values[1][0] = ppstCenter;
				PlotBrushes[1][0] = ppstCenter < (High[0] + Low[0]) / 2 ? Brushes.Blue : Brushes.Red;
			}
			else
			{
				Values[1][0] = double.NaN;
			}

			// Check and plot the signals
			bool bsignal = ppstTrend == 1 && CurrentBar > 0 && ppstTrendSeries[1] == -1;
			bool ssignal = ppstTrend == -1 && CurrentBar > 0 && ppstTrendSeries[1] == 1;

			if (PPST_ShowBuySellLabels)
			{
				if (bsignal)
				{
					Draw.ArrowUp(this, "PPSTBuyArrow" + CurrentBar, true, 0, trailingsl - 2 * TickSize, Brushes.Lime);
					Draw.Text(this, "PPSTBuyText" + CurrentBar, "Buy", 0, trailingsl - 4 * TickSize, Brushes.Lime);
				}
				if (ssignal)
				{
					Draw.ArrowDown(this, "PPSTSellArrow" + CurrentBar, true, 0, trailingsl + 2 * TickSize, Brushes.Red);
					Draw.Text(this, "PPSTSellText" + CurrentBar, "Sell", 0, trailingsl + 4 * TickSize, Brushes.Red);
				}
			}
		}
		
		private void ProcessSupport(PivotPoint newLow)
		{
			List<PivotPoint> recentLows = lowPivots.Where(p => p.Index >= CurrentBar - 100).OrderBy(p => p.Price).ToList();
			
			if (recentLows.Count >= TSR_SR_PointsToCheck)
			{
				var groupedLows = new List<List<PivotPoint>>();
				
				foreach (var low in recentLows)
				{
					bool grouped = false;
					foreach (var group in groupedLows)
					{
						if (Math.Abs(low.Price - group[0].Price) <= TickSize * 5)
						{
							group.Add(low);
							grouped = true;
							break;
						}
					}
					if (!grouped)
					{
						groupedLows.Add(new List<PivotPoint> { low });
					}
				}
				
				foreach (var group in groupedLows.Where(g => g.Count >= TSR_SR_PointsToCheck))
				{
					double avgPrice = group.Average(p => p.Price);
					int lastIndex = group.Max(p => p.Index);
					
					if (!supports.Any(s => Math.Abs(s.Price - avgPrice) <= TickSize * 2 && s.Index == lastIndex))
					{
						supports.Add(new SRLevel(lastIndex, avgPrice, "Support" + lineCounter++));
					}
				}
			}
		}
		
		private void ProcessResistance(PivotPoint newHigh)
		{
			List<PivotPoint> recentHighs = highPivots.Where(p => p.Index >= CurrentBar - 100).OrderByDescending(p => p.Price).ToList();
			
			if (recentHighs.Count >= TSR_SR_PointsToCheck)
			{
				var groupedHighs = new List<List<PivotPoint>>();
				
				foreach (var high in recentHighs)
				{
					bool grouped = false;
					foreach (var group in groupedHighs)
					{
						if (Math.Abs(high.Price - group[0].Price) <= TickSize * 5)
						{
							group.Add(high);
							grouped = true;
							break;
						}
					}
					if (!grouped)
					{
						groupedHighs.Add(new List<PivotPoint> { high });
					}
				}
				
				foreach (var group in groupedHighs.Where(g => g.Count >= TSR_SR_PointsToCheck))
				{
					double avgPrice = group.Average(p => p.Price);
					int lastIndex = group.Max(p => p.Index);
					
					if (!resistances.Any(r => Math.Abs(r.Price - avgPrice) <= TickSize * 2 && r.Index == lastIndex))
					{
						resistances.Add(new SRLevel(lastIndex, avgPrice, "Resistance" + lineCounter++));
					}
				}
			}
		}
		
		private void ProcessUptrends(PivotPoint newLow)
		{
			List<PivotPoint> recentLows = lowPivots.Where(p => p.Index < newLow.Index).OrderByDescending(p => p.Index).Take(TSR_TL_PointsToCheck).ToList();
			
			if (recentLows.Count >= 2 && recentLows[0].Price < newLow.Price)
			{
				TrendLineData trendLine = new TrendLineData(recentLows[0], newLow, "Uptrend" + lineCounter++);
				uptrends.Add(trendLine);
			}
		}
		
		private void ProcessDowntrends(PivotPoint newHigh)
		{
			List<PivotPoint> recentHighs = highPivots.Where(p => p.Index < newHigh.Index).OrderByDescending(p => p.Index).Take(TSR_TL_PointsToCheck).ToList();
			
			if (recentHighs.Count >= 2 && recentHighs[0].Price > newHigh.Price)
			{
				TrendLineData trendLine = new TrendLineData(recentHighs[0], newHigh, "Downtrend" + lineCounter++);
				downtrends.Add(trendLine);
			}
		}
		
		private void DrawTrendLines()
		{
			foreach (var trendLine in uptrends.Where(t => !t.IsViolated))
			{
				int startBarsAgo = CurrentBar - trendLine.Start.Index;
				int endBarsAgo = CurrentBar - trendLine.End.Index;
				
				if (startBarsAgo >= 0 && endBarsAgo >= 0)
				{
					Draw.Line(this, trendLine.Tag, true, startBarsAgo, trendLine.Start.Price, endBarsAgo, trendLine.End.Price, TSR_LowColor, DashStyleHelper.Solid, 2);
				}
			}
			
			foreach (var trendLine in downtrends.Where(t => !t.IsViolated))
			{
				int startBarsAgo = CurrentBar - trendLine.Start.Index;
				int endBarsAgo = CurrentBar - trendLine.End.Index;
				
				if (startBarsAgo >= 0 && endBarsAgo >= 0)
				{
					Draw.Line(this, trendLine.Tag, true, startBarsAgo, trendLine.Start.Price, endBarsAgo, trendLine.End.Price, TSR_HighColor, DashStyleHelper.Solid, 2);
				}
			}
		}
		
		private void DrawSupportResistance()
		{
			foreach (var support in supports)
			{
				int barsAgo = CurrentBar - support.Index;
				if (barsAgo >= 0 && barsAgo <= 50)
				{
					Draw.Rectangle(this, support.Tag, true, barsAgo, support.Price - TickSize, 0, support.Price + TickSize, TSR_LowColor, TSR_LowColor, 30);
				}
			}
			
			foreach (var resistance in resistances)
			{
				int barsAgo = CurrentBar - resistance.Index;
				if (barsAgo >= 0 && barsAgo <= 50)
				{
					Draw.Rectangle(this, resistance.Tag, true, barsAgo, resistance.Price - TickSize, 0, resistance.Price + TickSize, TSR_HighColor, TSR_HighColor, 30);
				}
			}
		}
		
		private double GetPPSTPivotHigh(int period)
		{
			if (CurrentBar < period * 2)
				return double.NaN;

			int centerBar = period;
			double centerHigh = High[centerBar];
			bool isPivot = true;

			for (int i = 1; i <= period; i++)
			{
				if (High[centerBar + i] >= centerHigh)
				{
					isPivot = false;
					break;
				}
			}

			if (isPivot)
			{
				for (int i = 1; i <= period; i++)
				{
					if (High[centerBar - i] > centerHigh)
					{
						isPivot = false;
						break;
					}
				}
			}

			return isPivot ? centerHigh : double.NaN;
		}

		private double GetPPSTPivotLow(int period)
		{
			if (CurrentBar < period * 2)
				return double.NaN;

			int centerBar = period;
			double centerLow = Low[centerBar];
			bool isPivot = true;

			for (int i = 1; i <= period; i++)
			{
				if (Low[centerBar + i] <= centerLow)
				{
					isPivot = false;
					break;
				}
			}

			if (isPivot)
			{
				for (int i = 1; i <= period; i++)
				{
					if (Low[centerBar - i] < centerLow)
					{
						isPivot = false;
						break;
					}
				}
			}

			return isPivot ? centerLow : double.NaN;
		}

		#region Properties
		
		// TrendLines S/R Properties
		[NinjaScriptProperty]
		[Range(1, 50)]
		[Display(Name="TSR Pivot Length", Order=1, GroupName="TrendLines S/R")]
		public int TSR_PivotLength
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="TSR Mark Pivots", Order=2, GroupName="TrendLines S/R")]
		public bool TSR_MarkPivots
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="TSR Trend Lines Enabled", Order=3, GroupName="TrendLines S/R")]
		public bool TSR_TrendLinesEnabled
		{ get; set; }

		[NinjaScriptProperty]
		[Range(2, 10)]
		[Display(Name="TSR TL Points To Check", Order=4, GroupName="TrendLines S/R")]
		public int TSR_TL_PointsToCheck
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="TSR S/R Enabled", Order=5, GroupName="TrendLines S/R")]
		public bool TSR_SR_Enabled
		{ get; set; }

		[NinjaScriptProperty]
		[Range(2, 10)]
		[Display(Name="TSR SR Points To Check", Order=6, GroupName="TrendLines S/R")]
		public int TSR_SR_PointsToCheck
		{ get; set; }

	[NinjaScriptProperty]
	[XmlIgnore]
	[Display(Name="TSR High Color", Order=7, GroupName="TrendLines S/R")]
	public Brush TSR_HighColor
	{ get; set; }

	[Browsable(false)]
	public string TSR_HighColorSerializable
	{
		get { return Serialize.BrushToString(TSR_HighColor); }
		set { TSR_HighColor = Serialize.StringToBrush(value); }
	}

	[NinjaScriptProperty]
	[XmlIgnore]
	[Display(Name="TSR Low Color", Order=8, GroupName="TrendLines S/R")]
	public Brush TSR_LowColor
	{ get; set; }

	[Browsable(false)]
	public string TSR_LowColorSerializable
	{
		get { return Serialize.BrushToString(TSR_LowColor); }
		set { TSR_LowColor = Serialize.StringToBrush(value); }
	}		// PPST Properties
		[NinjaScriptProperty]
		[Range(1, 50)]
		[Display(Name="PPST Pivot Period", Order=1, GroupName="Pivot Point SuperTrend")]
		public int PPST_PivotPeriod
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0.1, double.MaxValue)]
		[Display(Name="PPST ATR Factor", Order=2, GroupName="Pivot Point SuperTrend")]
		public double PPST_ATRFactor
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="PPST ATR Period", Order=3, GroupName="Pivot Point SuperTrend")]
		public int PPST_ATRPeriod
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="PPST Show Buy/Sell Labels", Order=4, GroupName="Pivot Point SuperTrend")]
		public bool PPST_ShowBuySellLabels
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="PPST Show Center Line", Order=5, GroupName="Pivot Point SuperTrend")]
		public bool PPST_ShowCenterLine
		{ get; set; }
		
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private CombinedTrendIndicator[] cacheCombinedTrendIndicator;
		public CombinedTrendIndicator CombinedTrendIndicator(int tSR_PivotLength, bool tSR_MarkPivots, bool tSR_TrendLinesEnabled, int tSR_TL_PointsToCheck, bool tSR_SR_Enabled, int tSR_SR_PointsToCheck, Brush tSR_HighColor, Brush tSR_LowColor, int pPST_PivotPeriod, double pPST_ATRFactor, int pPST_ATRPeriod, bool pPST_ShowBuySellLabels, bool pPST_ShowCenterLine)
		{
			return CombinedTrendIndicator(Input, tSR_PivotLength, tSR_MarkPivots, tSR_TrendLinesEnabled, tSR_TL_PointsToCheck, tSR_SR_Enabled, tSR_SR_PointsToCheck, tSR_HighColor, tSR_LowColor, pPST_PivotPeriod, pPST_ATRFactor, pPST_ATRPeriod, pPST_ShowBuySellLabels, pPST_ShowCenterLine);
		}

		public CombinedTrendIndicator CombinedTrendIndicator(ISeries<double> input, int tSR_PivotLength, bool tSR_MarkPivots, bool tSR_TrendLinesEnabled, int tSR_TL_PointsToCheck, bool tSR_SR_Enabled, int tSR_SR_PointsToCheck, Brush tSR_HighColor, Brush tSR_LowColor, int pPST_PivotPeriod, double pPST_ATRFactor, int pPST_ATRPeriod, bool pPST_ShowBuySellLabels, bool pPST_ShowCenterLine)
		{
			if (cacheCombinedTrendIndicator != null)
				for (int idx = 0; idx < cacheCombinedTrendIndicator.Length; idx++)
					if (cacheCombinedTrendIndicator[idx] != null && cacheCombinedTrendIndicator[idx].TSR_PivotLength == tSR_PivotLength && cacheCombinedTrendIndicator[idx].TSR_MarkPivots == tSR_MarkPivots && cacheCombinedTrendIndicator[idx].TSR_TrendLinesEnabled == tSR_TrendLinesEnabled && cacheCombinedTrendIndicator[idx].TSR_TL_PointsToCheck == tSR_TL_PointsToCheck && cacheCombinedTrendIndicator[idx].TSR_SR_Enabled == tSR_SR_Enabled && cacheCombinedTrendIndicator[idx].TSR_SR_PointsToCheck == tSR_SR_PointsToCheck && cacheCombinedTrendIndicator[idx].TSR_HighColor == tSR_HighColor && cacheCombinedTrendIndicator[idx].TSR_LowColor == tSR_LowColor && cacheCombinedTrendIndicator[idx].PPST_PivotPeriod == pPST_PivotPeriod && cacheCombinedTrendIndicator[idx].PPST_ATRFactor == pPST_ATRFactor && cacheCombinedTrendIndicator[idx].PPST_ATRPeriod == pPST_ATRPeriod && cacheCombinedTrendIndicator[idx].PPST_ShowBuySellLabels == pPST_ShowBuySellLabels && cacheCombinedTrendIndicator[idx].PPST_ShowCenterLine == pPST_ShowCenterLine && cacheCombinedTrendIndicator[idx].EqualsInput(input))
						return cacheCombinedTrendIndicator[idx];
			return CacheIndicator<CombinedTrendIndicator>(new CombinedTrendIndicator(){ TSR_PivotLength = tSR_PivotLength, TSR_MarkPivots = tSR_MarkPivots, TSR_TrendLinesEnabled = tSR_TrendLinesEnabled, TSR_TL_PointsToCheck = tSR_TL_PointsToCheck, TSR_SR_Enabled = tSR_SR_Enabled, TSR_SR_PointsToCheck = tSR_SR_PointsToCheck, TSR_HighColor = tSR_HighColor, TSR_LowColor = tSR_LowColor, PPST_PivotPeriod = pPST_PivotPeriod, PPST_ATRFactor = pPST_ATRFactor, PPST_ATRPeriod = pPST_ATRPeriod, PPST_ShowBuySellLabels = pPST_ShowBuySellLabels, PPST_ShowCenterLine = pPST_ShowCenterLine }, input, ref cacheCombinedTrendIndicator);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.CombinedTrendIndicator CombinedTrendIndicator(int tSR_PivotLength, bool tSR_MarkPivots, bool tSR_TrendLinesEnabled, int tSR_TL_PointsToCheck, bool tSR_SR_Enabled, int tSR_SR_PointsToCheck, Brush tSR_HighColor, Brush tSR_LowColor, int pPST_PivotPeriod, double pPST_ATRFactor, int pPST_ATRPeriod, bool pPST_ShowBuySellLabels, bool pPST_ShowCenterLine)
		{
			return indicator.CombinedTrendIndicator(Input, tSR_PivotLength, tSR_MarkPivots, tSR_TrendLinesEnabled, tSR_TL_PointsToCheck, tSR_SR_Enabled, tSR_SR_PointsToCheck, tSR_HighColor, tSR_LowColor, pPST_PivotPeriod, pPST_ATRFactor, pPST_ATRPeriod, pPST_ShowBuySellLabels, pPST_ShowCenterLine);
		}

		public Indicators.CombinedTrendIndicator CombinedTrendIndicator(ISeries<double> input , int tSR_PivotLength, bool tSR_MarkPivots, bool tSR_TrendLinesEnabled, int tSR_TL_PointsToCheck, bool tSR_SR_Enabled, int tSR_SR_PointsToCheck, Brush tSR_HighColor, Brush tSR_LowColor, int pPST_PivotPeriod, double pPST_ATRFactor, int pPST_ATRPeriod, bool pPST_ShowBuySellLabels, bool pPST_ShowCenterLine)
		{
			return indicator.CombinedTrendIndicator(input, tSR_PivotLength, tSR_MarkPivots, tSR_TrendLinesEnabled, tSR_TL_PointsToCheck, tSR_SR_Enabled, tSR_SR_PointsToCheck, tSR_HighColor, tSR_LowColor, pPST_PivotPeriod, pPST_ATRFactor, pPST_ATRPeriod, pPST_ShowBuySellLabels, pPST_ShowCenterLine);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.CombinedTrendIndicator CombinedTrendIndicator(int tSR_PivotLength, bool tSR_MarkPivots, bool tSR_TrendLinesEnabled, int tSR_TL_PointsToCheck, bool tSR_SR_Enabled, int tSR_SR_PointsToCheck, Brush tSR_HighColor, Brush tSR_LowColor, int pPST_PivotPeriod, double pPST_ATRFactor, int pPST_ATRPeriod, bool pPST_ShowBuySellLabels, bool pPST_ShowCenterLine)
		{
			return indicator.CombinedTrendIndicator(Input, tSR_PivotLength, tSR_MarkPivots, tSR_TrendLinesEnabled, tSR_TL_PointsToCheck, tSR_SR_Enabled, tSR_SR_PointsToCheck, tSR_HighColor, tSR_LowColor, pPST_PivotPeriod, pPST_ATRFactor, pPST_ATRPeriod, pPST_ShowBuySellLabels, pPST_ShowCenterLine);
		}

		public Indicators.CombinedTrendIndicator CombinedTrendIndicator(ISeries<double> input , int tSR_PivotLength, bool tSR_MarkPivots, bool tSR_TrendLinesEnabled, int tSR_TL_PointsToCheck, bool tSR_SR_Enabled, int tSR_SR_PointsToCheck, Brush tSR_HighColor, Brush tSR_LowColor, int pPST_PivotPeriod, double pPST_ATRFactor, int pPST_ATRPeriod, bool pPST_ShowBuySellLabels, bool pPST_ShowCenterLine)
		{
			return indicator.CombinedTrendIndicator(input, tSR_PivotLength, tSR_MarkPivots, tSR_TrendLinesEnabled, tSR_TL_PointsToCheck, tSR_SR_Enabled, tSR_SR_PointsToCheck, tSR_HighColor, tSR_LowColor, pPST_PivotPeriod, pPST_ATRFactor, pPST_ATRPeriod, pPST_ShowBuySellLabels, pPST_ShowCenterLine);
		}
	}
}

#endregion
