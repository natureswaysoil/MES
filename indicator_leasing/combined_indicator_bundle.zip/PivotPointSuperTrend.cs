#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

namespace NinjaTrader.NinjaScript.Indicators
{
	public class PivotPointSuperTrend : Indicator
	{
		private double center = double.NaN;
		private double tUp = double.NaN;
		private double tDown = double.NaN;
		private int trend = 0;
		private double support = double.NaN;
		private double resistance = double.NaN;
		
		private Series<double> pivotHighSeries;
		private Series<double> pivotLowSeries;
		private Series<double> centerSeries;
		private Series<double> tUpSeries;
		private Series<double> tDownSeries;
		private Series<int> trendSeries;
		private ATR atr;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description = @"Pivot Point SuperTrend indicator";
				Name = "Pivot Point SuperTrend";
				Calculate = Calculate.OnBarClose;
				IsOverlay = true;
				DisplayInDataBox = true;
				DrawOnPricePanel = true;
				DrawHorizontalGridLines = true;
				DrawVerticalGridLines = true;
				PaintPriceMarkers = true;
				ScaleJustification = NinjaTrader.Gui.Chart.ScaleJustification.Right;
				IsSuspendedWhileInactive = true;
				
				// Parameters
				PivotPeriod = 2;
				ATRFactor = 3.0;
				ATRPeriod = 10;
				ShowPivotPoints = false;
				ShowBuySellLabels = true;
				ShowCenterLine = false;
				ShowSupportResistance = false;
				
				// Plots
				AddPlot(Brushes.Lime, "SuperTrend");
				AddPlot(Brushes.Blue, "CenterLine");
				AddPlot(Brushes.Lime, "Support");
				AddPlot(Brushes.Red, "Resistance");
			}
			else if (State == State.Configure)
			{
				atr = ATR(ATRPeriod);
			}
			else if (State == State.DataLoaded)
			{
				pivotHighSeries = new Series<double>(this);
				pivotLowSeries = new Series<double>(this);
				centerSeries = new Series<double>(this);
				tUpSeries = new Series<double>(this);
				tDownSeries = new Series<double>(this);
				trendSeries = new Series<int>(this);
			}
		}

		protected override void OnBarUpdate()
		{
			if (CurrentBar < PivotPeriod * 2 + ATRPeriod)
			{
				pivotHighSeries[0] = 0;
				pivotLowSeries[0] = 0;
				centerSeries[0] = 0;
				tUpSeries[0] = 0;
				tDownSeries[0] = 0;
				trendSeries[0] = 0;
				Values[0][0] = double.NaN;
				Values[1][0] = double.NaN;
				Values[2][0] = double.NaN;
				Values[3][0] = double.NaN;
				return;
			}

			// Get Pivot High/Low
			double ph = GetPivotHigh(PivotPeriod);
			double pl = GetPivotLow(PivotPeriod);
			
			pivotHighSeries[0] = ph;
			pivotLowSeries[0] = pl;
			
			// Paint bars for S/R if enabled (paint at the current bar when pivot is detected)
			if (ShowSupportResistance)
			{
				if (!double.IsNaN(pl) && pl > 0)
				{
					// Paint support bar green at current bar
					BarBrush = Brushes.Lime;
					CandleOutlineBrush = Brushes.Green;
				}
				if (!double.IsNaN(ph) && ph > 0)
				{
					// Paint resistance bar red at current bar
					BarBrush = Brushes.Red;
					CandleOutlineBrush = Brushes.DarkRed;
				}
			}
			
			// Draw Pivot Points if enabled
			if (ShowPivotPoints)
			{
				if (!double.IsNaN(ph) && ph > 0)
				{
					Draw.Text(this, "PH" + CurrentBar, "H", PivotPeriod, High[PivotPeriod] + TickSize, Brushes.Red);
				}
				if (!double.IsNaN(pl) && pl > 0)
				{
					Draw.Text(this, "PL" + CurrentBar, "L", PivotPeriod, Low[PivotPeriod] - TickSize, Brushes.Lime);
				}
			}

			// Calculate the Center line using pivot points
			double lastpp = !double.IsNaN(ph) && ph > 0 ? ph : !double.IsNaN(pl) && pl > 0 ? pl : double.NaN;
			
			if (!double.IsNaN(lastpp))
			{
				if (double.IsNaN(center))
				{
					center = lastpp;
				}
				else
				{
					// Weighted calculation
					center = (center * 2 + lastpp) / 3;
				}
			}
			
			centerSeries[0] = center;

			// Upper/lower bands calculation
			double up = center - (ATRFactor * atr[0]);
			double dn = center + (ATRFactor * atr[0]);

			// Get the trend
			if (CurrentBar == 0)
			{
				tUp = up;
				tDown = dn;
				trend = 1;
			}
			else
			{
				tUp = Close[1] > tUpSeries[1] ? Math.Max(up, tUpSeries[1]) : up;
				tDown = Close[1] < tDownSeries[1] ? Math.Min(dn, tDownSeries[1]) : dn;
				
				if (Close[0] > tDownSeries[1])
					trend = 1;
				else if (Close[0] < tUpSeries[1])
					trend = -1;
				else
					trend = trendSeries[1] != 0 ? trendSeries[1] : 1;
			}
			
			tUpSeries[0] = tUp;
			tDownSeries[0] = tDown;
			trendSeries[0] = trend;

			double trailingsl = trend == 1 ? tUp : tDown;

			// Plot the trend with color
			Values[0][0] = trailingsl;
			
			if (trend == 1 && CurrentBar > 0 && trendSeries[1] == 1)
				PlotBrushes[0][0] = Brushes.Lime;
			else if (trend == -1 && CurrentBar > 0 && trendSeries[1] == -1)
				PlotBrushes[0][0] = Brushes.Red;
			else
				PlotBrushes[0][0] = Brushes.Transparent;

			// Plot center line
			if (ShowCenterLine)
			{
				Values[1][0] = center;
				PlotBrushes[1][0] = center < (High[0] + Low[0]) / 2 ? Brushes.Blue : Brushes.Red;
			}
			else
			{
				Values[1][0] = double.NaN;
			}

			// Check and plot the signals
			bool bsignal = trend == 1 && CurrentBar > 0 && trendSeries[1] == -1;
			bool ssignal = trend == -1 && CurrentBar > 0 && trendSeries[1] == 1;

			if (ShowBuySellLabels)
			{
				if (bsignal)
				{
					Draw.ArrowUp(this, "BuyArrow" + CurrentBar, true, 0, trailingsl - 2 * TickSize, Brushes.Lime);
					Draw.Text(this, "BuyText" + CurrentBar, "Buy", 0, trailingsl - 4 * TickSize, Brushes.Lime);
				}
				if (ssignal)
				{
					Draw.ArrowDown(this, "SellArrow" + CurrentBar, true, 0, trailingsl + 2 * TickSize, Brushes.Red);
					Draw.Text(this, "SellText" + CurrentBar, "Sell", 0, trailingsl + 4 * TickSize, Brushes.Red);
				}
			}

			// Get S/R levels using Pivot Points
			if (!double.IsNaN(pl) && pl > 0)
				support = pl;
			if (!double.IsNaN(ph) && ph > 0)
				resistance = ph;

			// Show S/R levels as plots if enabled
			if (ShowSupportResistance && !double.IsNaN(support) && !double.IsNaN(resistance))
			{
				Values[2][0] = support;
				Values[3][0] = resistance;
			}
			else
			{
				Values[2][0] = double.NaN;
				Values[3][0] = double.NaN;
			}
		}

		private double GetPivotHigh(int period)
		{
			if (CurrentBar < period * 2)
				return double.NaN;

			int centerBar = period;
			double centerHigh = High[centerBar];
			bool isPivot = true;

			// Check left side
			for (int i = 1; i <= period; i++)
			{
				if (High[centerBar + i] >= centerHigh)
				{
					isPivot = false;
					break;
				}
			}

			// Check right side
			if (isPivot)
			{
				for (int i = 1; i <= period; i++)
				{
					if (High[centerBar - i] > centerHigh)
					{
						isPivot = false;
						break;
					}
				}
			}

			return isPivot ? centerHigh : double.NaN;
		}

		private double GetPivotLow(int period)
		{
			if (CurrentBar < period * 2)
				return double.NaN;

			int centerBar = period;
			double centerLow = Low[centerBar];
			bool isPivot = true;

			// Check left side
			for (int i = 1; i <= period; i++)
			{
				if (Low[centerBar + i] <= centerLow)
				{
					isPivot = false;
					break;
				}
			}

			// Check right side
			if (isPivot)
			{
				for (int i = 1; i <= period; i++)
				{
					if (Low[centerBar - i] < centerLow)
					{
						isPivot = false;
						break;
					}
				}
			}

			return isPivot ? centerLow : double.NaN;
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(1, 50)]
		[Display(Name="Pivot Point Period", Description="Period for pivot point calculation", Order=1, GroupName="Parameters")]
		public int PivotPeriod
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0.1, double.MaxValue)]
		[Display(Name="ATR Factor", Description="ATR multiplication factor", Order=2, GroupName="Parameters")]
		public double ATRFactor
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="ATR Period", Description="Period for ATR calculation", Order=3, GroupName="Parameters")]
		public int ATRPeriod
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="Show Pivot Points", Description="Show pivot point labels", Order=4, GroupName="Display")]
		public bool ShowPivotPoints
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="Show Buy/Sell Labels", Description="Show buy and sell signals", Order=5, GroupName="Display")]
		public bool ShowBuySellLabels
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="Show Center Line", Description="Show pivot point center line", Order=6, GroupName="Display")]
		public bool ShowCenterLine
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="Show Support/Resistance", Description="Show support and resistance levels", Order=7, GroupName="Display")]
		public bool ShowSupportResistance
		{ get; set; }

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> SuperTrend
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> CenterLine
		{
			get { return Values[1]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Support
		{
			get { return Values[2]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Resistance
		{
			get { return Values[3]; }
		}
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private PivotPointSuperTrend[] cachePivotPointSuperTrend;
		public PivotPointSuperTrend PivotPointSuperTrend(int pivotPeriod, double aTRFactor, int aTRPeriod, bool showPivotPoints, bool showBuySellLabels, bool showCenterLine, bool showSupportResistance)
		{
			return PivotPointSuperTrend(Input, pivotPeriod, aTRFactor, aTRPeriod, showPivotPoints, showBuySellLabels, showCenterLine, showSupportResistance);
		}

		public PivotPointSuperTrend PivotPointSuperTrend(ISeries<double> input, int pivotPeriod, double aTRFactor, int aTRPeriod, bool showPivotPoints, bool showBuySellLabels, bool showCenterLine, bool showSupportResistance)
		{
			if (cachePivotPointSuperTrend != null)
				for (int idx = 0; idx < cachePivotPointSuperTrend.Length; idx++)
					if (cachePivotPointSuperTrend[idx] != null && cachePivotPointSuperTrend[idx].PivotPeriod == pivotPeriod && cachePivotPointSuperTrend[idx].ATRFactor == aTRFactor && cachePivotPointSuperTrend[idx].ATRPeriod == aTRPeriod && cachePivotPointSuperTrend[idx].ShowPivotPoints == showPivotPoints && cachePivotPointSuperTrend[idx].ShowBuySellLabels == showBuySellLabels && cachePivotPointSuperTrend[idx].ShowCenterLine == showCenterLine && cachePivotPointSuperTrend[idx].ShowSupportResistance == showSupportResistance && cachePivotPointSuperTrend[idx].EqualsInput(input))
						return cachePivotPointSuperTrend[idx];
			return CacheIndicator<PivotPointSuperTrend>(new PivotPointSuperTrend(){ PivotPeriod = pivotPeriod, ATRFactor = aTRFactor, ATRPeriod = aTRPeriod, ShowPivotPoints = showPivotPoints, ShowBuySellLabels = showBuySellLabels, ShowCenterLine = showCenterLine, ShowSupportResistance = showSupportResistance }, input, ref cachePivotPointSuperTrend);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.PivotPointSuperTrend PivotPointSuperTrend(int pivotPeriod, double aTRFactor, int aTRPeriod, bool showPivotPoints, bool showBuySellLabels, bool showCenterLine, bool showSupportResistance)
		{
			return indicator.PivotPointSuperTrend(Input, pivotPeriod, aTRFactor, aTRPeriod, showPivotPoints, showBuySellLabels, showCenterLine, showSupportResistance);
		}

		public Indicators.PivotPointSuperTrend PivotPointSuperTrend(ISeries<double> input , int pivotPeriod, double aTRFactor, int aTRPeriod, bool showPivotPoints, bool showBuySellLabels, bool showCenterLine, bool showSupportResistance)
		{
			return indicator.PivotPointSuperTrend(input, pivotPeriod, aTRFactor, aTRPeriod, showPivotPoints, showBuySellLabels, showCenterLine, showSupportResistance);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.PivotPointSuperTrend PivotPointSuperTrend(int pivotPeriod, double aTRFactor, int aTRPeriod, bool showPivotPoints, bool showBuySellLabels, bool showCenterLine, bool showSupportResistance)
		{
			return indicator.PivotPointSuperTrend(Input, pivotPeriod, aTRFactor, aTRPeriod, showPivotPoints, showBuySellLabels, showCenterLine, showSupportResistance);
		}

		public Indicators.PivotPointSuperTrend PivotPointSuperTrend(ISeries<double> input , int pivotPeriod, double aTRFactor, int aTRPeriod, bool showPivotPoints, bool showBuySellLabels, bool showCenterLine, bool showSupportResistance)
		{
			return indicator.PivotPointSuperTrend(input, pivotPeriod, aTRFactor, aTRPeriod, showPivotPoints, showBuySellLabels, showCenterLine, showSupportResistance);
		}
	}
}

#endregion
